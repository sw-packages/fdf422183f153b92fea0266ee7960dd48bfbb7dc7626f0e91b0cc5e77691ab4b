///////////////////////////////////////////////////////////////////////////////
// Name:        src/common/accesscmn.cpp
// Author:      Julian Smart
// Modified by:
// Created:     2003-02-12
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

#include "wx/wxprec.h"


#if wxUSE_ACCESSIBILITY

#include "wx/access.h"

#endif

